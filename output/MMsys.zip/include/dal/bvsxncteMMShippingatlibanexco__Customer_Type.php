<?php
$dalTableCustomer_Type = array();
$dalTableCustomer_Type["idCustomer_Type"] = array("type"=>3,"varname"=>"idCustomer_Type", "name" => "idCustomer_Type", "autoInc" => "1");
$dalTableCustomer_Type["Description"] = array("type"=>200,"varname"=>"Description", "name" => "Description", "autoInc" => "0");
$dalTableCustomer_Type["idCustomer_Type"]["key"]=true;

$dal_info["bvsxncteMMShippingatlibanexco__Customer_Type"] = &$dalTableCustomer_Type;
?>