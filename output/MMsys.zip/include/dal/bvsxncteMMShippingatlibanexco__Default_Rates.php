<?php
$dalTableDefault_Rates = array();
$dalTableDefault_Rates["idDefault Rates"] = array("type"=>3,"varname"=>"idDefault_Rates", "name" => "idDefault Rates", "autoInc" => "1");
$dalTableDefault_Rates["Description"] = array("type"=>200,"varname"=>"Description", "name" => "Description", "autoInc" => "0");
$dalTableDefault_Rates["Rate"] = array("type"=>5,"varname"=>"Rate", "name" => "Rate", "autoInc" => "0");
$dalTableDefault_Rates["idDefault Rates"]["key"]=true;

$dal_info["bvsxncteMMShippingatlibanexco__Default_Rates"] = &$dalTableDefault_Rates;
?>