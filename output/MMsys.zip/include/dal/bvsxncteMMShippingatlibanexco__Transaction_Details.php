<?php
$dalTableTransaction_Details = array();
$dalTableTransaction_Details["idTransaction_Details"] = array("type"=>3,"varname"=>"idTransaction_Details", "name" => "idTransaction_Details", "autoInc" => "1");
$dalTableTransaction_Details["Account"] = array("type"=>3,"varname"=>"Account", "name" => "Account", "autoInc" => "0");
$dalTableTransaction_Details["Transaction"] = array("type"=>3,"varname"=>"Transaction", "name" => "Transaction", "autoInc" => "0");
$dalTableTransaction_Details["Description"] = array("type"=>200,"varname"=>"Description", "name" => "Description", "autoInc" => "0");
$dalTableTransaction_Details["idTransaction_Details"]["key"]=true;

$dal_info["bvsxncteMMShippingatlibanexco__Transaction_Details"] = &$dalTableTransaction_Details;
?>