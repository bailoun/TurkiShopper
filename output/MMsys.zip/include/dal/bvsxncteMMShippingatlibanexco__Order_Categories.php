<?php
$dalTableOrder_Categories = array();
$dalTableOrder_Categories["idOrder_Categories"] = array("type"=>3,"varname"=>"idOrder_Categories", "name" => "idOrder_Categories", "autoInc" => "1");
$dalTableOrder_Categories["Description"] = array("type"=>200,"varname"=>"Description", "name" => "Description", "autoInc" => "0");
$dalTableOrder_Categories["idOrder_Categories"]["key"]=true;

$dal_info["bvsxncteMMShippingatlibanexco__Order_Categories"] = &$dalTableOrder_Categories;
?>