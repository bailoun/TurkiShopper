<?php
$dalTableOrder = array();
$dalTableOrder["idOrder"] = array("type"=>3,"varname"=>"idOrder", "name" => "idOrder", "autoInc" => "1");
$dalTableOrder["Customer"] = array("type"=>3,"varname"=>"Customer", "name" => "Customer", "autoInc" => "0");
$dalTableOrder["Shipment"] = array("type"=>3,"varname"=>"Shipment", "name" => "Shipment", "autoInc" => "0");
$dalTableOrder["Date_Ordered"] = array("type"=>7,"varname"=>"Date_Ordered", "name" => "Date_Ordered", "autoInc" => "0");
$dalTableOrder["Order_Description"] = array("type"=>200,"varname"=>"Order_Description", "name" => "Order_Description", "autoInc" => "0");
$dalTableOrder["Price_in_TL"] = array("type"=>5,"varname"=>"Price_in_TL", "name" => "Price_in_TL", "autoInc" => "0");
$dalTableOrder["Rate_for_Client"] = array("type"=>5,"varname"=>"Rate_for_Client", "name" => "Rate_for_Client", "autoInc" => "0");
$dalTableOrder["Price_in_\$"] = array("type"=>5,"varname"=>"Price_in__", "name" => "Price_in_\$", "autoInc" => "0");
$dalTableOrder["Order_Balance"] = array("type"=>5,"varname"=>"Order_Balance", "name" => "Order_Balance", "autoInc" => "0");
$dalTableOrder["Weight"] = array("type"=>5,"varname"=>"Weight", "name" => "Weight", "autoInc" => "0");
$dalTableOrder["Status"] = array("type"=>200,"varname"=>"Status", "name" => "Status", "autoInc" => "0");
$dalTableOrder["Notes"] = array("type"=>200,"varname"=>"Notes", "name" => "Notes", "autoInc" => "0");
$dalTableOrder["Link_to_Website"] = array("type"=>200,"varname"=>"Link_to_Website", "name" => "Link_to_Website", "autoInc" => "0");
$dalTableOrder["idOrder"]["key"]=true;

$dal_info["bvsxncteMMShippingatlibanexco__Order"] = &$dalTableOrder;
?>