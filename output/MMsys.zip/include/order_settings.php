<?php
$tdataorder = array();
$tdataorder[".searchableFields"] = array();
$tdataorder[".ShortName"] = "order";
$tdataorder[".OwnerID"] = "";
$tdataorder[".OriginalTable"] = "Order";


$tdataorder[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdataorder[".originalPagesByType"] = $tdataorder[".pagesByType"];
$tdataorder[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdataorder[".originalPages"] = $tdataorder[".pages"];
$tdataorder[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"masterlist\":\"masterlist\",\"masterprint\":\"masterprint\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdataorder[".originalDefaultPages"] = $tdataorder[".defaultPages"];

//	field labels
$fieldLabelsorder = array();
$fieldToolTipsorder = array();
$pageTitlesorder = array();
$placeHoldersorder = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsorder["English"] = array();
	$fieldToolTipsorder["English"] = array();
	$placeHoldersorder["English"] = array();
	$pageTitlesorder["English"] = array();
	$fieldLabelsorder["English"]["idOrder"] = "Order ID";
	$fieldToolTipsorder["English"]["idOrder"] = "";
	$placeHoldersorder["English"]["idOrder"] = "";
	$fieldLabelsorder["English"]["Customer"] = "Customer";
	$fieldToolTipsorder["English"]["Customer"] = "";
	$placeHoldersorder["English"]["Customer"] = "";
	$fieldLabelsorder["English"]["Shipment"] = "Shipment";
	$fieldToolTipsorder["English"]["Shipment"] = "";
	$placeHoldersorder["English"]["Shipment"] = "";
	$fieldLabelsorder["English"]["Date_Ordered"] = "Date Ordered";
	$fieldToolTipsorder["English"]["Date_Ordered"] = "";
	$placeHoldersorder["English"]["Date_Ordered"] = "";
	$fieldLabelsorder["English"]["Order_Description"] = "Order Description";
	$fieldToolTipsorder["English"]["Order_Description"] = "";
	$placeHoldersorder["English"]["Order_Description"] = "";
	$fieldLabelsorder["English"]["Price_in_TL"] = "Price In TL";
	$fieldToolTipsorder["English"]["Price_in_TL"] = "";
	$placeHoldersorder["English"]["Price_in_TL"] = "";
	$fieldLabelsorder["English"]["Rate_for_Client"] = "Rate For Client";
	$fieldToolTipsorder["English"]["Rate_for_Client"] = "";
	$placeHoldersorder["English"]["Rate_for_Client"] = "";
	$fieldLabelsorder["English"]["Price_in__"] = "Price In \$";
	$fieldToolTipsorder["English"]["Price_in__"] = "";
	$placeHoldersorder["English"]["Price_in__"] = "";
	$fieldLabelsorder["English"]["Weight"] = "Weight";
	$fieldToolTipsorder["English"]["Weight"] = "";
	$placeHoldersorder["English"]["Weight"] = "";
	$fieldLabelsorder["English"]["Status"] = "Status";
	$fieldToolTipsorder["English"]["Status"] = "";
	$placeHoldersorder["English"]["Status"] = "";
	$fieldLabelsorder["English"]["Notes"] = "Notes";
	$fieldToolTipsorder["English"]["Notes"] = "";
	$placeHoldersorder["English"]["Notes"] = "";
	$fieldLabelsorder["English"]["Order_Balance"] = "Order Balance";
	$fieldToolTipsorder["English"]["Order_Balance"] = "";
	$placeHoldersorder["English"]["Order_Balance"] = "";
	$fieldLabelsorder["English"]["Link_to_Website"] = "Link To Website";
	$fieldToolTipsorder["English"]["Link_to_Website"] = "";
	$placeHoldersorder["English"]["Link_to_Website"] = "";
	$pageTitlesorder["English"]["list"] = "Orders";
	if (count($fieldToolTipsorder["English"]))
		$tdataorder[".isUseToolTips"] = true;
}


	$tdataorder[".NCSearch"] = true;



$tdataorder[".shortTableName"] = "order";
$tdataorder[".nSecOptions"] = 0;

$tdataorder[".mainTableOwnerID"] = "";
$tdataorder[".entityType"] = 0;
$tdataorder[".connId"] = "bvsxncteMMShippingatlibanexco";


$tdataorder[".strOriginalTableName"] = "Order";

	



$tdataorder[".showAddInPopup"] = false;

$tdataorder[".showEditInPopup"] = false;

$tdataorder[".showViewInPopup"] = false;

$tdataorder[".listAjax"] = false;
//	temporary
//$tdataorder[".listAjax"] = false;

	$tdataorder[".audit"] = false;

	$tdataorder[".locking"] = false;


$pages = $tdataorder[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataorder[".edit"] = true;
	$tdataorder[".afterEditAction"] = 1;
	$tdataorder[".closePopupAfterEdit"] = 1;
	$tdataorder[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataorder[".add"] = true;
$tdataorder[".afterAddAction"] = 1;
$tdataorder[".closePopupAfterAdd"] = 1;
$tdataorder[".afterAddActionDetTable"] = "Sent";
}

if( $pages[PAGE_LIST] ) {
	$tdataorder[".list"] = true;
}



$tdataorder[".strSortControlSettingsJSON"] = "";

$tdataorder[".strClickActionJSON"] = "{\"fields\":{\"Category\":{\"action\":\"open\",\"codeData\":{},\"gridData\":{\"action\":\"checkbox\",\"table\":null},\"openData\":{\"how\":\"goto\",\"page\":\"view\",\"table\":null,\"url\":\"\"}},\"Customer\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Date_Ordered\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Expected_delivery_date\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Notes\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Order_Description\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Price_in_\$\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Price_in_TL\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Rate_for_Client\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Shipment\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Status\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"Weight\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}},\"idOrder\":{\"action\":\"noaction\",\"codeData\":{\"snippet\":\"\"},\"gridData\":{},\"openData\":{}}},\"row\":{\"action\":\"noaction\",\"codeData\":{},\"gridData\":{\"action\":\"checkbox\",\"table\":null},\"openData\":{\"how\":\"goto\",\"page\":\"view\",\"table\":null,\"url\":\"\"}}}";



if( $pages[PAGE_VIEW] ) {
$tdataorder[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataorder[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataorder[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataorder[".printFriendly"] = true;
}



$tdataorder[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataorder[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataorder[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataorder[".isUseAjaxSuggest"] = true;



									

$tdataorder[".ajaxCodeSnippetAdded"] = false;

$tdataorder[".buttonsAdded"] = false;

$tdataorder[".addPageEvents"] = true;

// use timepicker for search panel
$tdataorder[".isUseTimeForSearch"] = false;


$tdataorder[".badgeColor"] = "daa520";


$tdataorder[".allSearchFields"] = array();
$tdataorder[".filterFields"] = array();
$tdataorder[".requiredSearchFields"] = array();

$tdataorder[".googleLikeFields"] = array();
$tdataorder[".googleLikeFields"][] = "idOrder";
$tdataorder[".googleLikeFields"][] = "Customer";
$tdataorder[".googleLikeFields"][] = "Shipment";
$tdataorder[".googleLikeFields"][] = "Date_Ordered";
$tdataorder[".googleLikeFields"][] = "Order_Description";
$tdataorder[".googleLikeFields"][] = "Price_in_TL";
$tdataorder[".googleLikeFields"][] = "Rate_for_Client";
$tdataorder[".googleLikeFields"][] = "Price_in_\$";
$tdataorder[".googleLikeFields"][] = "Order_Balance";
$tdataorder[".googleLikeFields"][] = "Weight";
$tdataorder[".googleLikeFields"][] = "Status";
$tdataorder[".googleLikeFields"][] = "Notes";
$tdataorder[".googleLikeFields"][] = "Link_to_Website";



$tdataorder[".tableType"] = "list";

$tdataorder[".printerPageOrientation"] = 0;
$tdataorder[".nPrinterPageScale"] = 100;

$tdataorder[".nPrinterSplitRecords"] = 40;

$tdataorder[".geocodingEnabled"] = false;










$tdataorder[".pageSize"] = 20;

$tdataorder[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdataorder[".strOrderBy"] = $tstrOrderBy;

$tdataorder[".orderindexes"] = array();


$tdataorder[".sqlHead"] = "SELECT idOrder,  	Customer,  	Shipment,  	Date_Ordered,  	Order_Description,  	Price_in_TL,  	Rate_for_Client,  	`Price_in_\$`,  	Order_Balance,  	Weight,  	Status,  	Notes,  	Link_to_Website";
$tdataorder[".sqlFrom"] = "FROM `Order`";
$tdataorder[".sqlWhereExpr"] = "";
$tdataorder[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataorder[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataorder[".arrGroupsPerPage"] = $arrGPP;

$tdataorder[".highlightSearchResults"] = true;

$tableKeysorder = array();
$tableKeysorder[] = "idOrder";
$tdataorder[".Keys"] = $tableKeysorder;


$tdataorder[".hideMobileList"] = array();




//	idOrder
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "idOrder";
	$fdata["GoodName"] = "idOrder";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","idOrder");
	$fdata["FieldType"] = 3;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "idOrder";

		$fdata["sourceSingle"] = "idOrder";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "idOrder";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["idOrder"] = $fdata;
		$tdataorder[".searchableFields"][] = "idOrder";
//	Customer
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "Customer";
	$fdata["GoodName"] = "Customer";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Customer");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "Customer";

		$fdata["sourceSingle"] = "Customer";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Customer";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "Customer";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "idCustomer";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Name";

	

	
	$edata["LookupOrderBy"] = "idCustomer";

	
	
		$edata["AllowToAdd"] = true;
			$edata["addPageId"] = "add";

	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Customer"] = $fdata;
		$tdataorder[".searchableFields"][] = "Customer";
//	Shipment
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Shipment";
	$fdata["GoodName"] = "Shipment";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Shipment");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "Shipment";

		$fdata["sourceSingle"] = "Shipment";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Shipment";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Shipment"] = $fdata;
		$tdataorder[".searchableFields"][] = "Shipment";
//	Date_Ordered
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Date_Ordered";
	$fdata["GoodName"] = "Date_Ordered";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Date_Ordered");
	$fdata["FieldType"] = 7;


	
	
			

		$fdata["strField"] = "Date_Ordered";

		$fdata["sourceSingle"] = "Date_Ordered";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Date_Ordered";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
		$edata["weekdayMessage"] = array("message" => "Invalid week day", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 2;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Date_Ordered"] = $fdata;
		$tdataorder[".searchableFields"][] = "Date_Ordered";
//	Order_Description
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Order_Description";
	$fdata["GoodName"] = "Order_Description";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Order_Description");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Order_Description";

		$fdata["sourceSingle"] = "Order_Description";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Order_Description";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=45";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Order_Description"] = $fdata;
		$tdataorder[".searchableFields"][] = "Order_Description";
//	Price_in_TL
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Price_in_TL";
	$fdata["GoodName"] = "Price_in_TL";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Price_in_TL");
	$fdata["FieldType"] = 5;


	
	
			

		$fdata["strField"] = "Price_in_TL";

		$fdata["sourceSingle"] = "Price_in_TL";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Price_in_TL";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Price_in_TL"] = $fdata;
		$tdataorder[".searchableFields"][] = "Price_in_TL";
//	Rate_for_Client
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "Rate_for_Client";
	$fdata["GoodName"] = "Rate_for_Client";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Rate_for_Client");
	$fdata["FieldType"] = 5;


	
	
			

		$fdata["strField"] = "Rate_for_Client";

		$fdata["sourceSingle"] = "Rate_for_Client";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Rate_for_Client";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Rate_for_Client"] = $fdata;
		$tdataorder[".searchableFields"][] = "Rate_for_Client";
//	Price_in_$
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "Price_in_\$";
	$fdata["GoodName"] = "Price_in__";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Price_in__");
	$fdata["FieldType"] = 5;


	
	
			

		$fdata["strField"] = "Price_in_\$";

		$fdata["sourceSingle"] = "Price_in_\$";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Price_in_\$`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Price_in_\$"] = $fdata;
		$tdataorder[".searchableFields"][] = "Price_in_\$";
//	Order_Balance
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "Order_Balance";
	$fdata["GoodName"] = "Order_Balance";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Order_Balance");
	$fdata["FieldType"] = 5;


	
	
			

		$fdata["strField"] = "Order_Balance";

		$fdata["sourceSingle"] = "Order_Balance";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Order_Balance";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Custom");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Order_Balance"] = $fdata;
		$tdataorder[".searchableFields"][] = "Order_Balance";
//	Weight
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "Weight";
	$fdata["GoodName"] = "Weight";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Weight");
	$fdata["FieldType"] = 5;


	
	
			

		$fdata["strField"] = "Weight";

		$fdata["sourceSingle"] = "Weight";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Weight";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Weight"] = $fdata;
		$tdataorder[".searchableFields"][] = "Weight";
//	Status
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "Status";
	$fdata["GoodName"] = "Status";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Status");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Status";

		$fdata["sourceSingle"] = "Status";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Status";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=45";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Status"] = $fdata;
		$tdataorder[".searchableFields"][] = "Status";
//	Notes
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 12;
	$fdata["strName"] = "Notes";
	$fdata["GoodName"] = "Notes";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Notes");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Notes";

		$fdata["sourceSingle"] = "Notes";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Notes";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Notes"] = $fdata;
		$tdataorder[".searchableFields"][] = "Notes";
//	Link_to_Website
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 13;
	$fdata["strName"] = "Link_to_Website";
	$fdata["GoodName"] = "Link_to_Website";
	$fdata["ownerTable"] = "Order";
	$fdata["Label"] = GetFieldLabel("Order","Link_to_Website");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Link_to_Website";

		$fdata["sourceSingle"] = "Link_to_Website";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Link_to_Website";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataorder["Link_to_Website"] = $fdata;
		$tdataorder[".searchableFields"][] = "Link_to_Website";


$tables_data["Order"]=&$tdataorder;
$field_labels["Order"] = &$fieldLabelsorder;
$fieldToolTips["Order"] = &$fieldToolTipsorder;
$placeHolders["Order"] = &$placeHoldersorder;
$page_titles["Order"] = &$pageTitlesorder;


changeTextControlsToDate( "Order" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["Order"] = array();
//	Sent
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="Sent";
		$detailsParam["dOriginalTable"] = "Sent";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "sent";
	$detailsParam["dCaptionTable"] = GetTableCaption("Sent");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["Order"][$dIndex] = $detailsParam;

	
		$detailsTablesData["Order"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["Order"][$dIndex]["masterKeys"][]="idOrder";

				$detailsTablesData["Order"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["Order"][$dIndex]["detailKeys"][]="Order_ID";
//endif

// tables which are master tables for current table (detail)
$masterTablesData["Order"] = array();



	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="Customer";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="Customer";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "customer";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["Order"][0] = $masterParams;
				$masterTablesData["Order"][0]["masterKeys"] = array();
	$masterTablesData["Order"][0]["masterKeys"][]="idCustomer";
				$masterTablesData["Order"][0]["detailKeys"] = array();
	$masterTablesData["Order"][0]["detailKeys"][]="Customer";
		
	//endif
	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="Shipment";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="Shipment";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "shipment";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["Order"][1] = $masterParams;
				$masterTablesData["Order"][1]["masterKeys"] = array();
	$masterTablesData["Order"][1]["masterKeys"][]="idShipment";
				$masterTablesData["Order"][1]["detailKeys"] = array();
	$masterTablesData["Order"][1]["detailKeys"][]="Shipment";
		
	//endif
// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_order()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "idOrder,  	Customer,  	Shipment,  	Date_Ordered,  	Order_Description,  	Price_in_TL,  	Rate_for_Client,  	`Price_in_\$`,  	Order_Balance,  	Weight,  	Status,  	Notes,  	Link_to_Website";
$proto0["m_strFrom"] = "FROM `Order`";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "idOrder",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto6["m_sql"] = "idOrder";
$proto6["m_srcTableName"] = "Order";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "Customer",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto8["m_sql"] = "Customer";
$proto8["m_srcTableName"] = "Order";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Shipment",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto10["m_sql"] = "Shipment";
$proto10["m_srcTableName"] = "Order";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Date_Ordered",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto12["m_sql"] = "Date_Ordered";
$proto12["m_srcTableName"] = "Order";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Order_Description",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto14["m_sql"] = "Order_Description";
$proto14["m_srcTableName"] = "Order";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "Price_in_TL",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto16["m_sql"] = "Price_in_TL";
$proto16["m_srcTableName"] = "Order";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "Rate_for_Client",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto18["m_sql"] = "Rate_for_Client";
$proto18["m_srcTableName"] = "Order";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "Price_in_\$",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto20["m_sql"] = "`Price_in_\$`";
$proto20["m_srcTableName"] = "Order";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
						$proto22=array();
			$obj = new SQLField(array(
	"m_strName" => "Order_Balance",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto22["m_sql"] = "Order_Balance";
$proto22["m_srcTableName"] = "Order";
$proto22["m_expr"]=$obj;
$proto22["m_alias"] = "";
$obj = new SQLFieldListItem($proto22);

$proto0["m_fieldlist"][]=$obj;
						$proto24=array();
			$obj = new SQLField(array(
	"m_strName" => "Weight",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto24["m_sql"] = "Weight";
$proto24["m_srcTableName"] = "Order";
$proto24["m_expr"]=$obj;
$proto24["m_alias"] = "";
$obj = new SQLFieldListItem($proto24);

$proto0["m_fieldlist"][]=$obj;
						$proto26=array();
			$obj = new SQLField(array(
	"m_strName" => "Status",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto26["m_sql"] = "Status";
$proto26["m_srcTableName"] = "Order";
$proto26["m_expr"]=$obj;
$proto26["m_alias"] = "";
$obj = new SQLFieldListItem($proto26);

$proto0["m_fieldlist"][]=$obj;
						$proto28=array();
			$obj = new SQLField(array(
	"m_strName" => "Notes",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto28["m_sql"] = "Notes";
$proto28["m_srcTableName"] = "Order";
$proto28["m_expr"]=$obj;
$proto28["m_alias"] = "";
$obj = new SQLFieldListItem($proto28);

$proto0["m_fieldlist"][]=$obj;
						$proto30=array();
			$obj = new SQLField(array(
	"m_strName" => "Link_to_Website",
	"m_strTable" => "Order",
	"m_srcTableName" => "Order"
));

$proto30["m_sql"] = "Link_to_Website";
$proto30["m_srcTableName"] = "Order";
$proto30["m_expr"]=$obj;
$proto30["m_alias"] = "";
$obj = new SQLFieldListItem($proto30);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto32=array();
$proto32["m_link"] = "SQLL_MAIN";
			$proto33=array();
$proto33["m_strName"] = "Order";
$proto33["m_srcTableName"] = "Order";
$proto33["m_columns"] = array();
$proto33["m_columns"][] = "idOrder";
$proto33["m_columns"][] = "Customer";
$proto33["m_columns"][] = "Shipment";
$proto33["m_columns"][] = "Date_Ordered";
$proto33["m_columns"][] = "Order_Description";
$proto33["m_columns"][] = "Price_in_TL";
$proto33["m_columns"][] = "Rate_for_Client";
$proto33["m_columns"][] = "Price_in_\$";
$proto33["m_columns"][] = "Order_Balance";
$proto33["m_columns"][] = "Weight";
$proto33["m_columns"][] = "Status";
$proto33["m_columns"][] = "Notes";
$proto33["m_columns"][] = "Link_to_Website";
$obj = new SQLTable($proto33);

$proto32["m_table"] = $obj;
$proto32["m_sql"] = "`Order`";
$proto32["m_alias"] = "";
$proto32["m_srcTableName"] = "Order";
$proto34=array();
$proto34["m_sql"] = "";
$proto34["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto34["m_column"]=$obj;
$proto34["m_contained"] = array();
$proto34["m_strCase"] = "";
$proto34["m_havingmode"] = false;
$proto34["m_inBrackets"] = false;
$proto34["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto34);

$proto32["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto32);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="Order";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_order = createSqlQuery_order();


	
		;

													

$tdataorder[".sqlquery"] = $queryData_order;



include_once(getabspath("include/order_events.php"));
$tdataorder[".hasEvents"] = true;

?>