<?php

// create menu nodes arr
$menuNodes = array();
//Admin Area menu items
$menuNodesCache[ "adminarea" ] = $menuNodes;
	
?>
